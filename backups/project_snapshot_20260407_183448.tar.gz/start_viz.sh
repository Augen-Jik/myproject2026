#!/bin/bash
# ============================================================
#  start_viz.sh — 毕设可视化系统一键启动脚本
#  使用方法：bash start_viz.sh [--port PORT] [--mode MODE]
#  示例：bash start_viz.sh --port 8506 --mode demo_mode
# ============================================================

set -euo pipefail

# ── 颜色定义 ────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════╗"
echo "║   🚗  大模型驱动的交通路径规划可视化系统              ║"
echo "║   Open-R1 SFT · SUMO · A* Path Planning              ║"
echo "╚══════════════════════════════════════════════════════╝"
echo -e "${NC}"

# ── 解析命令行参数 ────────────────────────────────────────
PORT="${PORT:-6006}"
MODE="demo_mode"

while [[ $# -gt 0 ]]; do
    case $1 in
        --port) PORT="$2"; shift 2 ;;
        --mode) MODE="$2"; shift 2 ;;
        -h|--help)
            echo "用法: $0 [选项]"
            echo "选项:"
            echo "  --port PORT    指定端口 (默认: 6006)"
            echo "  --mode MODE    运行模式: demo_mode 或 experiment_mode (默认: demo_mode)"
            echo "  -h, --help     显示帮助"
            exit 0
            ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

# ── 配置项 ────────────────────────────────────────────────
APP_PATH="/root/autodl-tmp/code/app_fixed.py"
LOG_PATH="/root/autodl-tmp/logs/streamlit_${PORT}.log"
PYTHON_BIN="${PYTHON_BIN:-}"
STREAMLIT_CMD=()

# 自动选择可用 Python
if [ -z "$PYTHON_BIN" ]; then
    if command -v python3 >/dev/null 2>&1; then
        PYTHON_BIN="python3"
    elif command -v python >/dev/null 2>&1; then
        PYTHON_BIN="python"
    else
        echo -e "${RED}❌ 未找到可用的 Python 解释器${NC}"
        exit 1
    fi
fi

# 自动选择 Streamlit 启动方式
if "$PYTHON_BIN" -m streamlit --version >/dev/null 2>&1; then
    STREAMLIT_CMD=("$PYTHON_BIN" -m streamlit)
elif command -v streamlit >/dev/null 2>&1; then
    STREAMLIT_CMD=(streamlit)
else
    echo -e "${RED}❌ 未找到 streamlit，请先安装到当前 Python 环境${NC}"
    exit 1
fi

# ── 检查 app 文件 ────────────────────────────────────────────
echo -e "${YELLOW}[1/5] 检查应用文件...${NC}"
if [ -f "$APP_PATH" ]; then
    echo -e "${GREEN}✅ 应用文件存在：$APP_PATH${NC}"
else
    echo -e "${RED}❌ 应用文件不存在：$APP_PATH${NC}"
    exit 1
fi

# ── 停止旧进程 ───────────────────────────────────────────────
echo -e "${YELLOW}[2/5] 清理旧进程...${NC}"
OLD_PIDS=$(pgrep -f "streamlit run .*app_fixed.py.*--server.port $PORT" 2>/dev/null || true)
if [ -n "$OLD_PIDS" ]; then
    echo "$OLD_PIDS" | xargs -r kill 2>/dev/null || true
    sleep 1
    echo -e "${GREEN}✅ 已终止端口 $PORT 上的旧进程${NC}"
else
    echo -e "${GREEN}✅ 端口 $PORT 无旧进程${NC}"
fi

# ── 创建日志目录 ─────────────────────────────────────────────
mkdir -p "$(dirname "$LOG_PATH")"

# ── 启动服务 ─────────────────────────────────────────────────
echo -e "${YELLOW}[3/5] 启动 Streamlit 服务...${NC}"
RUN_MODE="$MODE" nohup "${STREAMLIT_CMD[@]}" run "$APP_PATH" \
    --server.port "$PORT" \
    --server.address 0.0.0.0 \
    --server.headless true \
    --server.enableCORS false \
    --server.enableXsrfProtection false \
    > "$LOG_PATH" 2>&1 &

NEW_PID=$!
sleep 4

# ── 验证启动 ─────────────────────────────────────────────────
echo -e "${YELLOW}[4/5] 验证启动状态...${NC}"
if ps -p "$NEW_PID" > /dev/null 2>&1; then
    echo -e "${GREEN}✅ 服务启动成功！PID: $NEW_PID${NC}"
else
    echo -e "${RED}❌ 启动失败，查看日志：${NC}"
    tail -20 "$LOG_PATH" || true
    exit 1
fi

# ── 检查端口 ─────────────────────────────────────────────────
echo -e "${YELLOW}[5/5] 检查端口监听...${NC}"
if command -v ss >/dev/null 2>&1 && ss -tlnp 2>/dev/null | grep -q ":$PORT "; then
    echo -e "${GREEN}✅ 端口 $PORT 监听正常${NC}"
else
    echo -e "${YELLOW}⚠️ 未能直接确认端口监听，但服务进程已启动${NC}"
fi

# ── 打印访问信息 ─────────────────────────────────────────────
echo ""
echo -e "${BLUE}══════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}🚀 服务已启动！${NC}"
echo ""
echo -e "  运行模式：${YELLOW}${MODE}${NC}"
echo -e "  监听端口：${YELLOW}${PORT}${NC}"
echo -e "  进程 PID：${YELLOW}${NEW_PID}${NC}"
echo ""
echo -e "  ${GREEN}访问地址：${NC}"
echo -e "  ${YELLOW}http://localhost:${PORT}${NC}"
echo ""
echo -e "  ${GREEN}AutoDL 公网访问：${NC}"
echo -e "  在 AutoDL 控制台 → 自定义服务 → 添加端口 ${PORT}"
echo ""
echo -e "  ${GREEN}常用命令：${NC}"
echo -e "  查看日志：${YELLOW}tail -f $LOG_PATH${NC}"
echo -e "  停止服务：${YELLOW}pkill -f 'streamlit.*app_fixed.*--server.port $PORT'${NC}"
echo -e "${BLUE}══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "📋 最近日志："
tail -8 "$LOG_PATH" 2>/dev/null || echo "  (日志文件尚未生成)"
