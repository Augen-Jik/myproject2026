import sumolib
import streamlit as st
import pandas as pd
import io

# Global cache for loaded networks
_net_cache = {}

def load_net_cached(net_path: str):
    """
    Load SUMO network with caching to avoid repeated loading.
    
    Args:
        net_path: Path to the .net.xml file
        
    Returns:
        tuple: (net_obj, edge_coords_dict)
    """
    global _net_cache
    
    if net_path in _net_cache:
        return _net_cache[net_path]
    
    try:
        net = sumolib.net.readNet(net_path)
        
        # Extract coordinates for all edges
        edge_coords = {}
        for edge in net.getEdges():
            shape = edge.getShape()
            if shape:
                coords = [(x, y) for x, y in shape]
                edge_coords[edge.getID()] = coords
        
        result = (net, edge_coords)
        _net_cache[net_path] = result
        return result
    except Exception as e:
        print(f"Error loading network {net_path}: {e}")
        raise

def safe_table_markdown(df: pd.DataFrame) -> str:
    """
    Safely convert DataFrame to markdown table avoiding issues with special characters.
    
    Args:
        df: Input DataFrame
        
    Returns:
        str: Safe markdown table representation
    """
    try:
        # Sanitize dataframe to prevent markdown rendering issues
        df_copy = df.copy()
        
        # Replace problematic characters in all cells
        for col in df_copy.columns:
            if df_copy[col].dtype == "object":
                df_copy[col] = df_copy[col].apply(
                    lambda x: str(x).replace('|', '\\|').replace('\n', ' ') if pd.notna(x) else x
                )
        
        # Convert to markdown with proper escaping
        buffer = io.StringIO()
        df_copy.to_markdown(buffer, tablefmt='github', index=False)
        markdown_str = buffer.getvalue()
        
        # Additional escaping if needed
        return markdown_str.replace("||", "| |")
    except Exception as e:
        # Fallback to simple representation
        return f"`Error generating table: {str(e)}`"

def clear_viz_cache():
    """Clear the visualization cache."""
    global _net_cache
    _net_cache.clear()
