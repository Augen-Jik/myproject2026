import os
import sys
import subprocess
import traci
import sumolib
import time
import logging
from typing import Dict, List, Tuple, Optional
import xml.etree.ElementTree as ET

class SUMORunner:
    """
    SUMO仿真运行器类，用于管理SUMO仿真过程
    """
    
    def __init__(self, config: Dict):
        self.config = config
        self.sumo_binary = config.get("SUMO_BINARY", "sumo")
        self.sumo_cmd = None
        self.is_running = False
        
        # 设置日志
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def start_simulation(self, net_file: str, route_file: str = None, additional_params: List[str] = None):
        """
        启动SUMO仿真
        
        Args:
            net_file: 网络文件路径
            route_file: 路线文件路径
            additional_params: 额外参数列表
        """
        try:
            # 构建SUMO命令
            cmd = [self.sumo_binary, "-n", net_file]
            
            if route_file:
                cmd.extend(["-r", route_file])
            
            # 添加额外参数
            if additional_params:
                cmd.extend(additional_params)
            
            # 添加默认参数以避免GUI
            cmd.extend(["--start", "--quit-on-end"])
            
            self.sumo_cmd = cmd
            self.logger.info(f"Starting SUMO with command: {' '.join(cmd)}")
            
            # 使用traci连接到SUMO
            traci.start(cmd)
            self.is_running = True
            
            self.logger.info("SUMO simulation started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start SUMO simulation: {e}")
            raise
    
    def stop_simulation(self):
        """停止SUMO仿真"""
        try:
            if self.is_running:
                traci.close()
                self.is_running = False
                self.logger.info("SUMO simulation stopped successfully")
        except Exception as e:
            self.logger.error(f"Error stopping SUMO simulation: {e}")
    
    def get_edge_info(self, edge_id: str) -> Dict:
        """
        获取边的信息
        
        Args:
            edge_id: 边ID
            
        Returns:
            包含边信息的字典
        """
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            edge_length = traci.edge.getLength(edge_id)
            edge_speed = traci.edge.getMaxSpeed(edge_id)
            edge_occupancy = traci.edge.getLastStepOccupancy(edge_id)
            edge_waiting_time = traci.edge.getWaitingTime(edge_id)
            edge_mean_speed = traci.edge.getLastStepMeanSpeed(edge_id)
            
            return {
                "id": edge_id,
                "length": edge_length,
                "max_speed": edge_speed,
                "occupancy": edge_occupancy,
                "waiting_time": edge_waiting_time,
                "mean_speed": edge_mean_speed
            }
        except Exception as e:
            self.logger.error(f"Error getting edge info for {edge_id}: {e}")
            return {}
    
    def get_all_edge_ids(self) -> List[str]:
        """获取所有边ID"""
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            return traci.edge.getIDList()
        except Exception as e:
            self.logger.error(f"Error getting edge IDs: {e}")
            return []
    
    def get_traffic_light_state(self, tl_id: str) -> str:
        """
        获取交通灯状态
        
        Args:
            tl_id: 交通灯ID
            
        Returns:
            交通灯状态字符串
        """
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            return traci.trafficlight.getRedYellowGreenState(tl_id)
        except Exception as e:
            self.logger.error(f"Error getting traffic light state for {tl_id}: {e}")
            return ""
    
    def set_traffic_light_state(self, tl_id: str, state: str):
        """
        设置交通灯状态
        
        Args:
            tl_id: 交通灯ID
            state: 新状态
        """
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            traci.trafficlight.setRedYellowGreenState(tl_id, state)
        except Exception as e:
            self.logger.error(f"Error setting traffic light state for {tl_id}: {e}")
    
    def step(self, step_amount: float = 1.0):
        """
        执行仿真步骤
        
        Args:
            step_amount: 步长时间（秒）
        """
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            traci.simulationStep(step_amount)
        except Exception as e:
            self.logger.error(f"Error during simulation step: {e}")
    
    def get_simulation_step(self) -> int:
        """获取当前仿真步骤"""
        if not self.is_running:
            return 0
        
        try:
            return traci.simulation.getCurrentStep()
        except Exception as e:
            self.logger.error(f"Error getting simulation step: {e}")
            return 0
    
    def get_vehicle_count(self) -> int:
        """获取当前车辆数量"""
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            return traci.simulation.getMinExpectedNumber()
        except Exception as e:
            self.logger.error(f"Error getting vehicle count: {e}")
            return 0
    
    def get_vehicle_info(self, veh_id: str) -> Dict:
        """
        获取车辆信息
        
        Args:
            veh_id: 车辆ID
            
        Returns:
            包含车辆信息的字典
        """
        if not self.is_running:
            raise RuntimeError("SUMO simulation is not running")
        
        try:
            return {
                "id": veh_id,
                "position": traci.vehicle.getPosition(veh_id),
                "speed": traci.vehicle.getSpeed(veh_id),
                "route": traci.vehicle.getRoute(veh_id),
                "lane": traci.vehicle.getLaneID(veh_id),
                "acceleration": traci.vehicle.getAcceleration(veh_id)
            }
        except Exception as e:
            self.logger.error(f"Error getting vehicle info for {veh_id}: {e}")
            return {}

def load_sumo_network(net_path: str) -> Tuple:
    """
    加载SUMO网络文件
    
    Args:
        net_path: 网络文件路径
        
    Returns:
        网络对象和边坐标字典
    """
    try:
        net = sumolib.net.readNet(net_path)
        
        # 提取所有边的坐标
        edge_coords = {}
        for edge in net.getEdges():
            shape = edge.getShape()
            if shape:
                coords = [(x, y) for x, y in shape]
                edge_coords[edge.getID()] = coords
        
        return net, edge_coords
    except Exception as e:
        print(f"Error loading SUMO network {net_path}: {e}")
        raise

def parse_net_file_for_edges(net_file_path: str) -> List[Dict]:
    """
    解析网络文件以获取边信息
    
    Args:
        net_file_path: 网络文件路径
        
    Returns:
        边信息列表
    """
    edges_info = []
    try:
        tree = ET.parse(net_file_path)
        root = tree.getroot()
        
        for edge_elem in root.findall('.//edge'):
            edge_info = {
                'id': edge_elem.get('id'),
                'from': edge_elem.get('from'),
                'to': edge_elem.get('to'),
                'priority': edge_elem.get('priority'),
                'speed': edge_elem.get('speed'),
                'length': edge_elem.get('length')
            }
            edges_info.append(edge_info)
        
        return edges_info
    except Exception as e:
        print(f"Error parsing net file {net_file_path}: {e}")
        return []

def get_total_edges_from_net(net_file_path: str) -> int:
    """
    从网络文件获取边总数
    
    Args:
        net_file_path: 网络文件路径
        
    Returns:
        边总数
    """
    try:
        edges = parse_net_file_for_edges(net_file_path)
        return len(edges)
    except Exception as e:
        print(f"Error counting edges in {net_file_path}: {e}")
        return 0  # 默认值，根据需求调整
