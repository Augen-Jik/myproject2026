from __future__ import annotations

import csv
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

# 统一结果根目录：项目内所有新结果均写入该根目录。
RESULTS_ROOT = "/root/autodl-tmp/results"
RUNS_SUBDIR = "runs"


@dataclass
class ResultBundle:
    run_id: str
    run_dir: str
    summary_json: str
    metrics_csv: str
    eval_report_txt: str
    config_snapshot_json: str


def now_utc_timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _slug(value: str, limit: int = 48) -> str:
    if value is None:
        value = "na"
    s = value.strip().lower()
    s = re.sub(r"[^a-z0-9._-]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-._")
    return (s or "na")[:limit]


def create_result_bundle(
    *,
    mode: str,
    planner: str,
    model: str,
    results_root: str = RESULTS_ROOT,
    timestamp: str | None = None,
) -> ResultBundle:
    ts = timestamp or now_utc_timestamp()
    run_id = f"{ts}__{_slug(mode)}__{_slug(planner)}__{_slug(model)}"
    run_dir = os.path.join(results_root, RUNS_SUBDIR, run_id)
    os.makedirs(run_dir, exist_ok=True)
    return ResultBundle(
        run_id=run_id,
        run_dir=run_dir,
        summary_json=os.path.join(run_dir, "summary.json"),
        metrics_csv=os.path.join(run_dir, "metrics.csv"),
        eval_report_txt=os.path.join(run_dir, "eval_report.txt"),
        config_snapshot_json=os.path.join(run_dir, "config_snapshot.json"),
    )


STANDARD_TIMING_KEYS = ("init_ms", "infer_ms", "smooth_ms", "total_ms", "cold_start")

def normalize_timing_info(
    timing: Mapping[str, Any] | None,
    *,
    defaults: Mapping[str, Any] | None = None,
    precision: int = 2,
) -> dict[str, Any]:
    """归一化标准计时字段，统一毫秒口径。"""
    base = {
        "init_ms": 0.0,
        "infer_ms": 0.0,
        "smooth_ms": 0.0,
        "total_ms": 0.0,
        "cold_start": False,
    }
    if defaults:
        for k in base:
            if k in defaults:
                base[k] = defaults[k]

    src = dict(timing or {})
    out = {}
    for k in ("init_ms", "infer_ms", "smooth_ms", "total_ms"):
        try:
            out[k] = round(float(src.get(k, base[k])), precision)
        except Exception:
            out[k] = round(float(base[k]), precision)
    out["cold_start"] = bool(src.get("cold_start", base["cold_start"]))
    return out

def write_json(path: str, payload: Any) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def write_text(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def write_metrics_csv(path: str, rows: Iterable[Mapping[str, Any]], field_order: list[str] | None = None) -> list[str]:
    rows = list(rows)
    if field_order:
        fields = list(field_order)
    else:
        field_set: list[str] = []
        seen = set()
        for row in rows:
            for k in row.keys():
                if k not in seen:
                    seen.add(k)
                    field_set.append(k)
        fields = field_set

    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return fields


def default_config_snapshot(
    *,
    timestamp: str,
    mode: str,
    seed: int,
    planner: str,
    model: str,
    scenarios: list[Any],
    fallback_policy: str,
    default_weight_policy: str,
    timing_policy: str,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    out = {
        "timestamp": timestamp,
        "mode": mode,
        "seed": seed,
        "planner": planner,
        "model": model,
        "scenario_list": scenarios,
        "fallback_policy": fallback_policy,
        "default_weight_policy": default_weight_policy,
        "timing_policy": timing_policy,
    }
    if extra:
        out.update(dict(extra))
    return out


def write_standard_artifacts(
    bundle: ResultBundle,
    *,
    summary: Mapping[str, Any],
    metrics_rows: Iterable[Mapping[str, Any]],
    report_text: str,
    config_snapshot: Mapping[str, Any],
    metrics_field_order: list[str] | None = None,
) -> None:
    write_json(bundle.summary_json, dict(summary))
    write_metrics_csv(bundle.metrics_csv, list(metrics_rows), field_order=metrics_field_order)
    write_text(bundle.eval_report_txt, report_text)
    write_json(bundle.config_snapshot_json, dict(config_snapshot))
