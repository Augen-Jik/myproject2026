"""
gat_smoother.py — LLM-GAT 级联协同决策架构（核心模块）

毕设创新点说明
==============
问题背景：小规模 LLM（1.5B 参数）在复杂交通场景下存在解析不完整的问题，
          且已解析权重可能存在空间不一致性（局部权重与周边拓扑不协调）。

本模块解决方案：
  1. [补全] 对缺失边，利用图邻居的已知权重进行拓扑推断
  2. [平滑] 对已解析边，利用路网拓扑结构进行空间一致性优化
  3. [异质] 注意力系数为主干道/次干道/支路学习不同影响权重

架构: LLM weights (partial) → Line-Graph GAT → refined weights → A*

参考文献: Veličković et al., "Graph Attention Networks", ICLR 2018

注：GAT 并非全场景必需，在高解析率场景下可能引入过度平滑。
    本模块主要用于低解析率或复杂拓扑场景的辅助增强。
"""

import math
import os
from typing import Optional, Dict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import sumolib
except Exception:  # pragma: no cover - SUMO runtime may be absent in some environments.
    sumolib = None

# ════════════════════════════════════════════════════════════
#  路网静态定义（与 generate_dataset_cot.py 完全一致）
# ════════════════════════════════════════════════════════════

N_ROWS   = 5   # 农业路 红专路 政七街 黄河路 纬五路
N_COLS   = 6   # 经一路 经三路 经六路 经八路 花园路 未来路
ROW_TYPE = ['A', 'S', 'M', 'A', 'M']   # A=主干道 S=次干道 M=支路
COL_TYPE = ['M', 'S', 'A', 'S', 'A', 'M']
TYPE2ID  = {'A': 0, 'S': 1, 'M': 2}

EDGES: list[str] = []
EDGE_META: dict  = {}

for _r in range(N_ROWS):
    for _c in range(N_COLS - 1):
        for _d in ['E', 'W']:
            _eid = f"R{_r}C{_c}_{_d}"
            EDGES.append(_eid)
            EDGE_META[_eid] = {
                'axis': 'H', 'row': _r, 'col': _c,
                'rtype': ROW_TYPE[_r],
                'start': (_r, _c)   if _d == 'E' else (_r, _c + 1),
                'end':   (_r, _c+1) if _d == 'E' else (_r, _c),
            }

for _c in range(N_COLS):
    for _r in range(N_ROWS - 1):
        for _d in ['N', 'S']:
            _eid = f"C{_c}R{_r}_{_d}"
            EDGES.append(_eid)
            EDGE_META[_eid] = {
                'axis': 'V', 'row': _r, 'col': _c,
                'rtype': COL_TYPE[_c],
                'start': (_r, _c)   if _d == 'N' else (_r+1, _c),
                'end':   (_r+1, _c) if _d == 'N' else (_r,   _c),
            }

SUMO_NET_PATH = "/root/autodl-tmp/SUMO/net/my_net.net.xml"
if sumolib is not None and os.path.exists(SUMO_NET_PATH):
    try:
        _live_net = sumolib.net.readNet(SUMO_NET_PATH)
        _live_edges = [edge.getID() for edge in _live_net.getEdges() if edge is not None]
        if _live_edges:
            _live_set = set(_live_edges)
            EDGES = [eid for eid in EDGES if eid in _live_set]
            EDGE_META = {eid: EDGE_META[eid] for eid in EDGES}
    except Exception as exc:
        print(f"⚠️  读取实时SUMO路网失败，继续使用静态98边定义: {exc}")

EDGE_IDX = {e: i for i, e in enumerate(EDGES)}
N_EDGES = len(EDGES)


# ════════════════════════════════════════════════════════════
#  图结构预计算
# ════════════════════════════════════════════════════════════

def build_line_graph_adj() -> torch.Tensor:
    """
    构建路网「线图」邻接矩阵 A ∈ {0,1}^{98×98}

    线图定义：将 98 条有向路段视为节点，
    若两条路段共享同一交叉口（端点），则在线图中相连。

    物理含义：邻接 → 在该交叉口处路段之间存在拥堵传播关系。
    使用无向版本（对称化）以保证 GAT 数值稳定性。
    """
    A = torch.zeros(N_EDGES, N_EDGES)
    node_to_edges: dict = {}

    for i, eid in enumerate(EDGES):
        m = EDGE_META[eid]
        for node in [m['start'], m['end']]:
            node_to_edges.setdefault(node, []).append(i)

    for edge_list in node_to_edges.values():
        for i in edge_list:
            for j in edge_list:
                if i != j:
                    A[i][j] = 1.0   # 无向：同时设 A[i,j] 和 A[j,i]

    return A


def build_road_type_onehot() -> torch.Tensor:
    """
    返回 [98, 3] 的道路类型 one-hot 矩阵
    列顺序：[主干道A, 次干道S, 支路M]
    作为 GAT 输入的辅助特征，让注意力机制感知道路等级
    """
    feats = torch.zeros(N_EDGES, 3)
    for i, eid in enumerate(EDGES):
        feats[i, TYPE2ID[EDGE_META[eid]['rtype']]] = 1.0
    return feats


# ════════════════════════════════════════════════════════════
#  GAT 层实现
# ════════════════════════════════════════════════════════════

class GATLayer(nn.Module):
    """
    单层图注意力网络

    核心公式（单头）：
        e_ij = LeakyReLU( aᵀ · [W hᵢ ‖ W hⱼ] )   # 注意力系数（未归一化）
        α_ij = softmax_j( e_ij )                    # 归一化（仅对邻居 j）
        h'_i = ELU( Σ_j α_ij · W hⱼ )              # 新节点特征

    多头扩展：K 个独立注意力头，最后 concat 或 mean。

    参数：
        in_dim   输入特征维度
        out_dim  每个注意力头的输出维度
        n_heads  注意力头数量
        concat   True → concat 多头输出；False → mean 多头输出
    """

    def __init__(self, in_dim: int, out_dim: int,
                 n_heads: int = 4, dropout: float = 0.1,
                 concat: bool = True):
        super().__init__()
        self.out_dim = out_dim
        self.n_heads = n_heads
        self.concat  = concat

        # 线性变换（各头共享权重矩阵 W）
        self.W = nn.Linear(in_dim, out_dim * n_heads, bias=False)

        # 注意力向量 a，形状 [n_heads, 2*out_dim]
        self.a = nn.Parameter(torch.empty(n_heads, 2 * out_dim))
        nn.init.xavier_uniform_(self.a.unsqueeze(0))

        self.leaky_relu = nn.LeakyReLU(negative_slope=0.2)
        self.drop       = nn.Dropout(dropout)

    def forward(self, h: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        """
        h   : [N, in_dim]     节点特征矩阵
        adj : [N, N]          邻接矩阵（0/1，支持 batch 外广播）
        返回: [N, out_dim*n_heads]（concat=True）或 [N, out_dim]（concat=False）
        """
        N = h.size(0)
        K = self.n_heads
        D = self.out_dim

        # 线性变换 → [N, K, D]
        Wh = self.W(h).view(N, K, D)

        # 构建所有节点对 (i,j) 的拼接特征 → [N, N, K, 2D]
        Wh_i = Wh.unsqueeze(1).expand(N, N, K, D)   # 广播行
        Wh_j = Wh.unsqueeze(0).expand(N, N, K, D)   # 广播列
        cat  = torch.cat([Wh_i, Wh_j], dim=-1)      # [N, N, K, 2D]

        # 注意力得分 [N, N, K]
        # self.a: [K, 2D]  →  [1, 1, K, 2D]  →  element-wise × cat → sum → [N,N,K]
        e = self.leaky_relu((cat * self.a).sum(dim=-1))

        # 屏蔽非邻居：将其设为 -inf，使 softmax 后权重为 0
        mask = (adj == 0).unsqueeze(-1).expand_as(e)  # [N, N, K]
        e    = e.masked_fill(mask, float('-inf'))

        # 归一化 [N, N, K]
        alpha = F.softmax(e, dim=1)    # 对所有邻居 j 归一化
        alpha = torch.nan_to_num(alpha, nan=0.0)  # 处理孤立节点
        alpha = self.drop(alpha)

        # 加权聚合 h'[i,k,d] = Σ_j α[i,j,k] * Wh[j,k,d]
        out = torch.einsum('ijk,jkd->ikd', alpha, Wh)  # [N, K, D]

        if self.concat:
            return F.elu(out.reshape(N, K * D))   # [N, K*D]
        else:
            return out.mean(dim=1)                 # [N, D]（不激活，由后续层处理）


# ════════════════════════════════════════════════════════════
#  完整 GAT 模型
# ════════════════════════════════════════════════════════════

class RoadGAT(nn.Module):
    """
    面向城市路网权重平滑与补全的两层 GAT

    输入特征（每节点/边）：
        - LLM 输出权重（归一化到 [0,1]）：1 维
        - 道路类型 one-hot（主干/次干/支路）：3 维
        → 合计 4 维输入

    网络结构：
        Input [98, 4]
        → GAT-L1 (4→8, 4heads, concat) → [98, 32]  捕获局部拓扑模式
        → GAT-L2 (32→8, 4heads, mean)  → [98, 8]   全局平滑
        → MLP (8→1) + Sigmoid×10       → [98]       输出精炼权重

    训练目标（有监督）：
        - 输入：LLM 解析的部分权重（模拟 50/98 场景，缺失填 0）
        - 输出：完整 98 条路段的真实权重
        - 损失：MSELoss（对已解析边权重更高，mask 加权）

    推理时：
        - 已解析边：blend = α × LLM + (1-α) × GAT
        - 缺失边：  = GAT 推断值（邻居传播补全）
    """

    def __init__(self, n_heads: int = 4, hidden: int = 32, dropout: float = 0.1):
        super().__init__()

        in_dim = 4   # weight(1) + type_onehot(3)

        self.gat1 = GATLayer(in_dim,           hidden, n_heads, dropout, concat=True)
        self.gat2 = GATLayer(hidden * n_heads, hidden, n_heads, dropout, concat=False)

        self.head = nn.Sequential(
            nn.Linear(hidden, 16),
            nn.ELU(),
            nn.Linear(16, 1),
            nn.Sigmoid(),
        )

        # 固定图结构缓冲区（不参与梯度计算）
        self.register_buffer('adj',        build_line_graph_adj())
        self.register_buffer('type_feats', build_road_type_onehot())

    def forward(self, w: torch.Tensor) -> torch.Tensor:
        """
        w: [98] 或 [B, 98]，LLM 权重（缺失边为 0），范围 [0, 10]
        返回: 同形状的精炼权重 [0, 10]
        """
        squeeze = (w.dim() == 1)
        if squeeze:
            w = w.unsqueeze(0)        # [1, 98]

        B = w.size(0)
        # 向量化：将 B 个样本拼成 [B*98, 4]，一次性过两层 GAT
        # type_feats [98,3] → 广播到 [B,98,3] → reshape [B*98,3]
        w_norm  = (w / 10.0).unsqueeze(-1)                          # [B,98,1]
        tf      = self.type_feats.unsqueeze(0).expand(B, -1, -1)    # [B,98,3]
        x_flat  = torch.cat([w_norm, tf], dim=-1).view(B * N_EDGES, 4)  # [B*98,4]

        # 扩展邻接矩阵以匹配展平后的节点顺序（每个样本独立图）
        # 注意：GAT 在单图上运行，逐样本处理保持正确性；
        # 此处以循环+cat 代替复杂的块对角矩阵，保持代码可读性
        outs = []
        for b in range(B):
            xb = x_flat[b * N_EDGES:(b + 1) * N_EDGES]  # [98,4]
            h  = self.gat1(xb, self.adj)                 # [98,128]
            h  = self.gat2(h,  self.adj)                 # [98,32]
            outs.append(self.head(h).squeeze(-1) * 10)   # [98]

        out = torch.stack(outs)   # [B,98]
        return out.squeeze(0) if squeeze else out


# ════════════════════════════════════════════════════════════
#  监督训练（在合成数据集上预训练 GAT）
# ════════════════════════════════════════════════════════════

def train_gat(
    dataset_path: str = "/root/autodl-tmp/dataset_cot/train/data.parquet",
    save_path:    str = "/root/autodl-tmp/gat_model.pt",
    epochs:       int = 150,
    lr:           float = 1e-3,
    batch_size:   int = 64,
    device:       str = "cuda" if torch.cuda.is_available() else "cpu",
    mask_ratio:   float = 0.45,   # 模拟 LLM 只解析 ~50% 的场景
) -> RoadGAT:
    """
    在合成数据集上训练 GAT（有监督）

    训练策略：
        - 从数据集中随机遮盖 mask_ratio 的边权重（设为 0），模拟 LLM 解析不完整
        - 让 GAT 预测全部 98 条边的真实权重
        - 用 MSE Loss，对缺失边赋予更高权重（迫使 GAT 学会补全而不只是复制）

    说明：不强制依赖此函数，可直接调用 smooth_weights() 使用未训练版本（基于结构先验）
    """
    import json, re
    import pyarrow.parquet as _pq
    import numpy as _np

    print(f"🔍 加载训练数据: {dataset_path}")
    # 直接用 pyarrow 读，完全绕过 pandas 的类型转换
    _table = _pq.read_table(dataset_path)
    # 转成 Python list[str]，避免 numpy.ndarray 类型歧义
    _col = _table.column('messages')
    rows = [v.as_py() if hasattr(v, 'as_py') else str(v)
            for v in _col]

    # 解析权重
    pat = re.compile(r'([RC]\d+[RC]\d+_[EWNS])\s*[:：]\s*(\d+(?:\.\d+)?)')
    all_targets = []
    for msg_str in rows:
        if isinstance(msg_str, str):
            msgs = json.loads(msg_str)
        elif isinstance(msg_str, list):
            msgs = msg_str
        else:
            msgs = json.loads(str(msg_str))
        resp = next((m['content'] for m in msgs if m['role'] == 'assistant'), '')
        if '</think>' in resp:
            resp = resp.split('</think>')[-1]
        wd = {e: float(w) for e, w in pat.findall(resp) if e in EDGE_IDX}
        if len(wd) >= 90:   # 只用完整样本
            vec = torch.tensor([wd.get(e, 2.0) for e in EDGES])
            all_targets.append(vec)

    if len(all_targets) < 10:
        print("⚠️  有效样本不足，跳过训练")
        return RoadGAT().to(device)

    targets = torch.stack(all_targets)   # [N, 98]
    print(f"✅ 有效训练样本: {len(targets)}")

    model     = RoadGAT(hidden=32).to(device)
    # ★ lr 从 1e-3 降到 3e-4：extreme_wt=8 时梯度大，高lr导致震荡
    optimizer = torch.optim.Adam(model.parameters(), lr=min(lr, 3e-4), weight_decay=1e-4)
    # Warmup + Cosine：前10%epoch线性升温，之后余弦退火
    def _lr_lambda(ep):
        warmup = int(epochs * 0.1)
        if ep < warmup:
            return ep / warmup
        prog = (ep - warmup) / (epochs - warmup)
        return 0.5 * (1 + math.cos(math.pi * prog))
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, _lr_lambda)

    best_loss = float('inf')
    model.train()
    for epoch in range(epochs):
        idx        = torch.randperm(len(targets))
        total_loss = 0.0
        steps      = 0

        for start in range(0, len(targets), batch_size):
            batch = targets[idx[start:start + batch_size]].to(device)   # [B, 98]

            # 随机遮盖（模拟 LLM 解析不完整，45%遮盖≈测试4的52/98场景）
            mask = torch.rand_like(batch) > mask_ratio   # True=保留
            inp  = batch * mask.float()                  # 缺失处置 0

            pred = model(inp)

            # ★ 权重损失策略（修复震荡问题）：
            #   - 缺失边 2×（让 GAT 学会补全，但不要过大）
            #   - 极端值 4×（保证封闭/畅通路段被精确还原，从8.0降到4.0）
            #   - 两者叠加时取最大值（避免指数爆炸）
            w_missing = torch.where(~mask, torch.full_like(batch, 2.0), torch.ones_like(batch))
            w_extreme = torch.where((batch > 7.5) | (batch < 1.0),
                                     torch.full_like(batch, 4.0), torch.ones_like(batch))
            loss_wt   = torch.max(w_missing, w_extreme)
            loss      = ((pred - batch) ** 2 * loss_wt).mean()

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 0.5)   # 梯度裁剪更严
            optimizer.step()

            total_loss += loss.item()
            steps      += 1

        scheduler.step()
        avg_loss = total_loss / steps
        if avg_loss < best_loss:
            best_loss = avg_loss   # 记录最优

        if (epoch + 1) % 5 == 0:
            print(f"  Epoch {epoch+1:3d}/{epochs}  loss={avg_loss:.4f}  best={best_loss:.4f}")

    # 保存权重
    _dir = os.path.dirname(save_path)
    if _dir:
        os.makedirs(_dir, exist_ok=True)
    torch.save(model.state_dict(), save_path)
    print(f"✅ GAT 模型已保存 → {save_path}")
    return model


# ════════════════════════════════════════════════════════════
#  主推理接口
# ════════════════════════════════════════════════════════════

_cached_model: Optional[RoadGAT] = None


def load_gat_model(
    model_path: str = "/root/autodl-tmp/gat_model.pt",
    device:     str = "cpu",
) -> RoadGAT:
    """加载预训练 GAT（有缓存避免重复加载）"""
    global _cached_model
    if _cached_model is not None:
        return _cached_model

    model = RoadGAT().to(device)
    if os.path.exists(model_path):
        checkpoint = torch.load(model_path, map_location=device)
        model_state = model.state_dict()
        compatible = {
            key: value
            for key, value in checkpoint.items()
            if key in model_state and getattr(model_state[key], "shape", None) == getattr(value, "shape", None)
        }
        if compatible:
            model.load_state_dict(compatible, strict=False)
            if len(compatible) == len(checkpoint):
                print(f"✅ GAT 模型已加载: {model_path}")
            else:
                print(
                    f"⚠️  GAT 权重与当前{N_EDGES}边路网部分不兼容，已加载 {len(compatible)}/{len(checkpoint)} 个兼容参数: {model_path}"
                )
        else:
            print(f"⚠️  GAT 权重与当前{N_EDGES}边路网不兼容，使用随机初始化: {model_path}")
    else:
        print(f"⚠️  未找到预训练权重 {model_path}，使用随机初始化（结构平滑模式）")
    model.eval()
    _cached_model = model
    return model


def smooth_weights(
    llm_weight_dict: Dict[str, float],
    model_path: str = "/root/autodl-tmp/gat_model.pt",
    alpha:      float = 0.65,
    device:     str   = "cpu",
) -> Dict[str, float]:
    """
    LLM 权重字典 → GAT 精炼后的完整权重字典（修复版）

    自适应 alpha 策略：
      解析率≥90%  → alpha=0.90（完整解析，GAT仅轻度平滑）
      解析率60-90% → alpha=0.75
      解析率<60%  → alpha=0.55（大量缺失，GAT主导补全）

    保护机制：LLM 确认的极高权重（封闭/严重拥堵）不被 GAT 平滑掉
    """
    model = load_gat_model(model_path, device)

    # 构造输入向量（缺失边填 0）
    raw_vec     = torch.zeros(N_EDGES)
    parsed_mask = torch.zeros(N_EDGES, dtype=torch.bool)

    for eid, w in llm_weight_dict.items():
        if eid in EDGE_IDX:
            i              = EDGE_IDX[eid]
            raw_vec[i]     = float(w)
            parsed_mask[i] = True

    llm_parsed_n = parsed_mask.sum().item()

    # 自适应 alpha（基于解析率）
    if llm_parsed_n >= 90:
        alpha = 0.90
    elif llm_parsed_n >= 60:
        alpha = 0.75
    else:
        alpha = 0.55

    # ★ 场景复杂度自适应：权重分布方差大时降低 α，增强 GAT 平滑能力
    parsed_vals = [v for k, v in llm_weight_dict.items() if k in EDGE_IDX and v != 2.0]
    if len(parsed_vals) >= 3:
        import numpy as _np
        _std = float(_np.std(parsed_vals))
        if _std > 1.5:
            alpha = max(alpha - 0.10, 0.45)
            print(f"  [GAT] 复杂拥堵分布(std={_std:.2f})，α 降至 {alpha:.2f}")

    # ★ 动态极端值保护阈值：自适应到最高权重的 85%，保护中高拥堵路段
    max_w = max(llm_weight_dict.values()) if llm_weight_dict else 8.0
    HIGH_THRESHOLD = min(8.0, max(5.5, max_w * 0.85))
    protected = {k: v for k, v in llm_weight_dict.items()
                 if v >= HIGH_THRESHOLD and k in EDGE_IDX}

    with torch.no_grad():
        gat_vec = model(raw_vec.to(device)).cpu()

    # 混合策略
    refined = torch.where(
        parsed_mask,
        alpha * raw_vec + (1 - alpha) * gat_vec,
        gat_vec,
    ).clamp(0.3, 10.0)

    result = {EDGES[i]: round(refined[i].item(), 2) for i in range(N_EDGES)}

    # 恢复被保护的极端权重
    for eid, w in protected.items():
        result[eid] = max(result.get(eid, w), w)

    missing = N_EDGES - llm_parsed_n
    if missing > 0:
        print(f"  [GAT] LLM解析 {int(llm_parsed_n)}/98，GAT补全 {int(missing)} 条，alpha={alpha:.2f}")

    return result, alpha


# ════════════════════════════════════════════════════════════
#  可视化工具（论文附图用）
# ════════════════════════════════════════════════════════════

def get_attention_matrix(
    llm_weight_dict: Dict[str, float],
    model_path: str = "/root/autodl-tmp/gat_model.pt",
    head: int = 0,
) -> np.ndarray:
    """
    返回 GAT 第一层第 head 号注意力头的系数矩阵 [98, 98]
    可用于论文中的热力图可视化，展示拥堵影响关系
    """
    model = load_gat_model(model_path)

    raw_vec = torch.zeros(N_EDGES)
    for eid, w in llm_weight_dict.items():
        if eid in EDGE_IDX:
            raw_vec[EDGE_IDX[eid]] = float(w)

    type_feats = model.type_feats
    x = torch.cat([(raw_vec / 10.0).unsqueeze(-1), type_feats], dim=-1)

    # 手动提取注意力系数（不经过完整 forward）
    with torch.no_grad():
        N  = N_EDGES
        K  = model.gat1.n_heads
        D  = model.gat1.out_dim
        Wh = model.gat1.W(x).view(N, K, D)

        Wh_i = Wh.unsqueeze(1).expand(N, N, K, D)
        Wh_j = Wh.unsqueeze(0).expand(N, N, K, D)
        cat  = torch.cat([Wh_i, Wh_j], dim=-1)
        e    = model.gat1.leaky_relu((cat * model.gat1.a).sum(dim=-1))

        mask = (model.gat1_adj == 0) if hasattr(model, 'gat1_adj') else (model.adj == 0)
        mask = mask.unsqueeze(-1).expand_as(e)
        e    = e.masked_fill(mask, float('-inf'))
        alpha = F.softmax(e, dim=1)  # [N, N, K]

    return alpha[:, :, head].numpy()


# ════════════════════════════════════════════════════════════
#  快速测试入口
# ════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 55)
    print("  RoadGAT 快速测试")
    print("=" * 55)

    # 模拟 LLM 只解析了 50 条边
    import random
    random.seed(0)
    partial_edges = random.sample(EDGES, 50)
    llm_out = {e: random.uniform(1.0, 9.0) for e in partial_edges}
    print(f"  LLM 解析边数: {len(llm_out)}/{N_EDGES}")

    # 精炼
    refined, alpha_used = smooth_weights(llm_out)
    print(f"  GAT 输出边数: {len(refined)}/{N_EDGES}  alpha={alpha_used:.2f}")
    print(f"  前5条: { {k: v for k, v in list(refined.items())[:5]} }")

    # 模型参数量
    m = RoadGAT(hidden=32)
    params = sum(p.numel() for p in m.parameters())
    print(f"\n  GAT 参数量: {params:,}（极轻量，推理 <1ms）")

    # 邻接矩阵统计
    A = build_line_graph_adj()
    deg = A.sum(dim=1)
    print(f"  线图平均度: {deg.mean():.1f}  最大度: {deg.max():.0f}")
    print("=" * 55)
