# Main Results

## Table 1. Main Results

| Method | Avg SUMO Time (s) | Avg Constraint Rate (%) | Avg Inference Time (s) | Avg Planning Time (ms) | Avg Signal Ratio (%) |
| --- | --- | --- | --- | --- | --- |
| Sparse-LoRA+GAT | 503.47 | 68.23 | 1.48 | 0.07 | 61.45 |
| Sparse-LoRA | 511.15 | 68.23 | 1.47 | 0.08 | 9.38 |
| Rule-A* | 513.55 | 61.57 | 0.00 | 0.07 | 91.70 |
| Qwen-LoRA | 591.95 | 47.42 | 15.86 | 0.05 | 34.72 |
| R1-LoRA | 785.65 | 42.73 | 31.49 | 0.07 | 51.73 |

## Table 2. Scenario-level Delta Analysis

| Scenario | Base Method | Enhanced Method | ΔSUMO Time (s) | ΔConstraint Rate (%) | ΔInference Time (s) | GAT Helpful? |
| --- | --- | --- | --- | --- | --- | --- |
| 场景A 黄河路单向拥堵 | Sparse-LoRA | Sparse-LoRA+GAT | 0.00 | 0.00 | 0.02 | No |
| 场景B 花园路封闭绕行 | Sparse-LoRA | Sparse-LoRA+GAT | 0.00 | 0.00 | 0.02 | No |
| 场景C 多路段复合拥堵 | Sparse-LoRA | Sparse-LoRA+GAT | 0.00 | 0.00 | 0.02 | No |
| 场景D 中央核心节点封锁（强迫大范围绕行） | Sparse-LoRA | Sparse-LoRA+GAT | -46.10 | 0.00 | -0.02 | Yes |
| 场景E 不对称方向拥堵（测试模型方向提取能力） | Sparse-LoRA | Sparse-LoRA+GAT | 0.00 | 0.00 | -0.01 | No |
| 场景F 大规模复合灾害（极限压力测试） | Sparse-LoRA | Sparse-LoRA+GAT | 0.00 | 0.00 | 0.00 | No |
| 场景A 黄河路单向拥堵 | Rule-A* | Sparse-LoRA+GAT | 0.00 | 0.00 | 1.17 | No |
| 场景B 花园路封闭绕行 | Rule-A* | Sparse-LoRA+GAT | 0.00 | 0.00 | 1.16 | No |
| 场景C 多路段复合拥堵 | Rule-A* | Sparse-LoRA+GAT | 0.00 | 0.00 | 1.52 | No |
| 场景D 中央核心节点封锁（强迫大范围绕行） | Rule-A* | Sparse-LoRA+GAT | 0.00 | 40.00 | 1.86 | Yes |
| 场景E 不对称方向拥堵（测试模型方向提取能力） | Rule-A* | Sparse-LoRA+GAT | -60.50 | 0.00 | 1.35 | Yes |
| 场景F 大规模复合灾害（极限压力测试） | Rule-A* | Sparse-LoRA+GAT | 0.00 | 0.00 | 1.83 | No |